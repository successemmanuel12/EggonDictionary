package com.successemmanuel.eggondictionary.Notification;


public class AlarmReciever {
 /*   public void showNotification(View view){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.drawable.elag);
        builder.setContentTitle("Word Of The Day");
        builder.setContentText((CharSequence) word);
        builder.setTicker("The Word For Today");

        Intent intent = new Intent(AlarmReciever.this, DefinitionActivity.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(DefinitionActivity.class);
        stackBuilder.addNextIntent(intent);
        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManager NM = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        NM.notify(0,builder.build());
        NM.cancel(0);
    }*/
}
